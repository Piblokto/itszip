##########################
# Game Configuration for Player
# for hard play with 30
# for medium play with 45
# for easy play with 60
timer_length = 45
## DO NOT LEAVE THIS BLANK


# Define Sprites as Variables from file location
Sprites = {
	"background" : "../sprites/Background/background.png",
	"ground_1" : "../sprites/Tile/Ground/ground_1.png",
	"ground_2" : "../sprites/Tile/Ground/ground_2.png",
	"ground_3" : "../sprites/Tile/Ground/ground_3.png",
	"ground_4" : "../sprites/Tile/Ground/ground_4.png",
	"ground_5" : "../sprites/Tile/Ground/ground_5.png",
	"ground_6" : "../sprites/Tile/Ground/ground_6.png",
	"ground_7" : "../sprites/Tile/Ground/ground_7.png",
	"ground_8" : "../sprites/Tile/Ground/ground_8.png",
	"ground_9" : "../sprites/Tile/Ground/ground_9.png",
	"ground_10" : "../sprites/Tile/Ground/ground_10.png",
	"ground_11" : "../sprites/Tile/Ground/ground_11.png",
	"grass_1" : "../sprites/Tile/Grass/grass_1.png",
	"grass_2" : "../sprites/Tile/Grass/grass_2.png",
	"grass_3" : "../sprites/Tile/Grass/grass_3.png",
	"grass_4" : "../sprites/Tile/Grass/grass_4.png",
	"grass_5" : "../sprites/Tile/Grass/grass_5.png",
	"bush_1" : "../sprites/Decor/Bush/bush_1.png",
	"bush_2" : "../sprites/Decor/Bush/bush_2.png",
	"tree_1" : "../sprites/Decor/Tree/tree.png",
	"tree_2" : "../sprites/Decor/Tree/tree_dead.png",
	"rock_1" : "../sprites/Decor/Rock/rock_1.png",
	"rock_2" : "../sprites/Decor/Rock/rock_2.png",
	"sign"	: "../sprites/Items/sign.png",
	"lava" : "../sprites/Tile/Ground/lava.png"
}

# Player Sprites
Player = {
	"idle_1" : "../sprites/Player/idle_1.png",
	"idle_2" : "../sprites/Player/idle_2.png",
	"idle_3" : "../sprites/Player/idle_3.png",
	"idle_4" : "../sprites/Player/idle_4.png",
	"run_1" : "../sprites/Player/run_1.png",
	"run_2" : "../sprites/Player/run_2.png",
	"run_3" : "../sprites/Player/run_3.png",
	"run_4" : "../sprites/Player/run_4.png",
	"run_5" : "../sprites/Player/run_5.png",
	"run_6" : "../sprites/Player/run_6.png",
	"death_1" : "../sprites/Player/death_1.png",
	"death_2" : "../sprites/Player/death_2.png",
	"death_3" : "../sprites/Player/death_3.png",
	"death_4" : "../sprites/Player/death_4.png",
	"death_5" : "../sprites/Player/death_5.png",
	"death_6" : "../sprites/Player/death_6.png",
	"death_7" : "../sprites/Player/death_7.png",
	"death_8" : "../sprites/Player/death_8.png",
	"jump_1" : "../sprites/Player/jump_1.png",
	"jump_2" : "../sprites/Player/jump_2.png"
}


# UI Sprites
UI = {
	"continue" : "../sprites/UI/continue_button.png",
	"play" : "../sprites/UI/play_button.png",
	"quit" : "../sprites/UI/quit_button.png",
	"resume" : "../sprites/UI/resume_button.png",
	"save" : "../sprites/UI/save_button.png",
	"load" : "../sprites/UI/load_button.png"
}

# Sound
Sounds = {
	"jump" : "../sounds/jump.wav",
	"over" : "../sounds/game_over.wav",
	"theme" : "../sounds/theme.mp3",
	"complete" : "../sounds/game_complete.wav"
}